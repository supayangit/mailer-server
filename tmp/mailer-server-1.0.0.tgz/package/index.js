import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import cookieParser from 'cookie-parser'
import { auth } from './auth.js'
import { sendWelcomeEmail } from './emailService.js'

const app = express()
const PORT = process.env.PORT || 5000

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
}))
app.use(express.json())
app.use(cookieParser())

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'Server is running' })
})

// ==================== AUTH ROUTES ====================

// Sign In Route
app.post('/auth/signin', async (req, res) => {
  try {
    const { email, password } = req.body

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' })
    }

    // Use BetterAuth's built-in sign in
    const response = await auth.api.signInEmail(req, res, {
      email,
      password,
      callbackURL: `${process.env.FRONTEND_URL}/dashboard`,
    })

    if (!response.ok) {
      return res.status(401).json({ error: 'Invalid credentials' })
    }

    const user = await response.json()
    return res.json(user)
  } catch (err) {
    console.error('Signin error:', err)
    return res.status(500).json({ error: 'Internal server error' })
  }
})

// Sign Up Route
app.post('/auth/signup', async (req, res) => {
  try {
    const { email, password, name } = req.body

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' })
    }

    // Use BetterAuth's built-in sign up
    const response = await auth.api.signUpEmail(req, res, {
      email,
      password,
      name,
      callbackURL: `${process.env.FRONTEND_URL}/dashboard`,
    })

    if (!response.ok) {
      const error = await response.json()
      return res.status(response.status).json(error)
    }

    const user = await response.json()

    // Send welcome email (best-effort, don't block signup)
    setImmediate(async () => {
      try {
        await sendWelcomeEmail(email, name || 'User')
      } catch (e) {
        console.warn('Failed to send welcome email:', e.message)
      }
    })

    return res.json(user)
  } catch (err) {
    console.error('Signup error:', err)
    return res.status(500).json({ error: 'Internal server error' })
  }
})

// Google OAuth Route
app.post('/auth/google', async (req, res) => {
  try {
    // BetterAuth handles OAuth flow - this endpoint should return OAuth redirect
    const response = await auth.api.getOAuthRedirectURL(req, res, 'google')
    return res.json(response)
  } catch (err) {
    console.error('Google OAuth error:', err)
    return res.status(500).json({ error: 'Internal server error' })
  }
})

// Sign Out Route
app.post('/auth/signout', async (req, res) => {
  try {
    const response = await auth.api.signOut(req, res)
    return res.json({ message: 'Signed out successfully' })
  } catch (err) {
    console.error('Signout error:', err)
    return res.status(500).json({ error: 'Internal server error' })
  }
})

// Get Current User Route
app.get('/auth/me', async (req, res) => {
  try {
    const user = await auth.api.getSession(req, res)
    if (!user) {
      return res.status(401).json({ error: 'Not authenticated' })
    }
    return res.json(user)
  } catch (err) {
    console.error('Get user error:', err)
    return res.status(500).json({ error: 'Internal server error' })
  }
})

// ==================== EMAIL ROUTES ====================

// Send Welcome Email Route
app.post('/send-welcome-email', async (req, res) => {
  try {
    const { email, name } = req.body

    if (!email) {
      return res.status(400).json({ error: 'Email is required' })
    }

    await sendWelcomeEmail(email, name || 'User')
    return res.json({ message: 'Welcome email sent successfully' })
  } catch (err) {
    console.error('Send welcome email error:', err)
    return res.status(500).json({ error: 'Failed to send welcome email' })
  }
})

// ==================== ERROR HANDLING ====================

// 404 Handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' })
})

// Error Handler
app.use((err, req, res, next) => {
  console.error('Server error:', err)
  res.status(500).json({ error: 'Internal server error' })
})

// Start Server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`)
  console.log(`📧 Frontend URL: ${process.env.FRONTEND_URL}`)
})
